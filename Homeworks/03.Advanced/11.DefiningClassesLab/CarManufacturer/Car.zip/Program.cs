﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            //1st and 2nd tasks
            //Car car = new Car();

            //car.Make = "VW";
            //car.Model = "MK3";
            //car.Year = 1992;
            //car.FuelQuantity = 500;
            //car.FuelConsumption = 7;
            //car.Drive(50);

            //-----------------------------------------------

            //3th task
            //List<Car> cars = new List<Car>();
            //string make = Console.ReadLine();
            //string model = Console.ReadLine();
            //int year = int.Parse(Console.ReadLine());
            //double fuelQuantity = double.Parse(Console.ReadLine());
            //double fuelConsumotion= double.Parse(Console.ReadLine());

            //Car firstCar = new Car();
            //firstCar.Drive(2);
            //cars.Add(firstCar);

            //Car secondCar = new Car(make, model, year);
            //secondCar.Drive(2);
            //cars.Add(secondCar);

            //Car thirdCar = new Car(make, model, year, fuelQuantity, fuelConsumotion);
            //thirdCar.Drive(2);
            //cars.Add(thirdCar);

            //foreach (var car in cars)
            //{
            //    Console.WriteLine(car.WhoAmI());
            //    Console.WriteLine(new string('-', 20));
            //}

            //-----------------------------------------------

            //4th task
            Tire[] tires = new Tire[4]
            {
                new Tire(1, 2.5),
                new Tire(1, 2.1),
                new Tire(2, 0.5),
                new Tire(2, 2.3),
            };

            Engine engine = new Engine(560, 6300);
            Car cars = new Car("Lamborghini", "Urus", 2010, 250, 9, engine, tires);

            Console.WriteLine($"Make: {cars.Make}\nModel: {cars.Model}\nYear: {cars.Year}\nFuel: {cars.FuelQuantity:F2}L\nEngine:\n-HorsePower: {cars.Engine.HorsePower}\n-CubicCapacity: {cars.Engine.CubicCapacity}\nTires:");

            foreach (var tire in tires)
            {
                Console.WriteLine($"-Pressure: {tire.Pressure}");
                Console.WriteLine($"-Year: {tire.Year}");
            }
        }
    }
}
