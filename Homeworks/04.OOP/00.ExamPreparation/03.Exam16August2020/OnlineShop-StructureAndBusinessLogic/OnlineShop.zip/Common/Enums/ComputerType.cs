﻿namespace OnlineShop.Common.Enums
{
    public enum ComputerType
    {
        DesktopComputer = 1,
        Laptop = 2,
    }
}