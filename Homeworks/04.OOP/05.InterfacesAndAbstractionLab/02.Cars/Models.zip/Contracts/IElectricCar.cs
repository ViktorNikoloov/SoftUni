﻿namespace Cars.Contracts
{
    public interface IElectricCar
    {
        public int Battery { get; set; }
    }
}
