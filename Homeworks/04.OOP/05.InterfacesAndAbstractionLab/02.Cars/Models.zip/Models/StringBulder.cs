﻿namespace Cars.Models
{
    internal class StringBulder
    {
        public StringBulder()
        {
        }
    }
}