﻿namespace _03.Telephony.Models.Contracts
{
    public interface IBrowseable
    {
        public string Browse(string url);
    }
}
