﻿namespace _03.Telephony.IO.Contracts
{
    public interface IReader
    {
        public string ReadLine();
    }
}
