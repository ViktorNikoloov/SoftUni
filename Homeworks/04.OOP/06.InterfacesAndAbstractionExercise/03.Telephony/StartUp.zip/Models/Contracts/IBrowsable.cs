﻿namespace _03.Telephony.Models.Contracts
{
    public interface IBrowsable
    {
        public string Browse(string url);
    }
}
