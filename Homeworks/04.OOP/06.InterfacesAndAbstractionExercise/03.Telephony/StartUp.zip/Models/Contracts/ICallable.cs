﻿namespace _03.Telephony.Models.Contracts
{
    public interface ICallable
    {
        public string Call(string number);
    }
}
