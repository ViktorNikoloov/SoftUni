﻿namespace _05.BirthdayCelebrations.IO.Contracts
{
    public interface IReader
    {
        public string ReadLine();
    }
}
