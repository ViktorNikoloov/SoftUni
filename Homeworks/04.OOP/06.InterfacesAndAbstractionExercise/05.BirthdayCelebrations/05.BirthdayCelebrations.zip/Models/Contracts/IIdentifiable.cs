﻿namespace _05.BirthdayCelebrations.Models.Contracts
{
    interface IIdentifiable
    {
        public string Id { get;}


    }
}
