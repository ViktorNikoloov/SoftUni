﻿namespace _05.BirthdayCelebrations.Models.Contracts
{
    interface IRobot : IIdentifiable
    {
        public string Model { get; }
    }
}
