﻿namespace Animals.Models.Contracts
{
    public interface ICat : IAnimal
    {

    }
}
