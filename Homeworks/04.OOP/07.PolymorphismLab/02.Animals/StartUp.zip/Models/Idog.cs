﻿namespace Animals.Models
{
    internal interface Idog
    {
    }
}