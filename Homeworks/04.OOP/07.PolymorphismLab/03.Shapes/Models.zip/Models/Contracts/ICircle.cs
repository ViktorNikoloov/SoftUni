﻿namespace Shapes.Models.Contracts
{
    public interface ICircle
    {
        public double Radius  { get;}
    }
}
