﻿
namespace Shapes.Models.Contracts
{
    public interface IRectangle
    {
        public double Height { get; }

        public double Width { get; }
    }
}
