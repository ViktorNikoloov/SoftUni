﻿namespace _03.Raiding.Common
{
    public static class ExceptionMessages
    {
        public const string InvalidHeroMsg = "Invalid hero!";
    }
}
