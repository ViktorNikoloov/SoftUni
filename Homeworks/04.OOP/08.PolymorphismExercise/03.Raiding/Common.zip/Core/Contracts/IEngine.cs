﻿namespace _03.Raiding.Core.Contracts
{
    public interface IEngine
    {
        public void Run();
    }
}
