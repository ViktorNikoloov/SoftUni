﻿namespace _03.Raiding.IO.Contracts
{
    public interface IReader
    {
        public string ReadLine();
    }
}
