﻿namespace _03.Raiding.Models.Contracts
{
    public interface IDruid : IHero
    {

    }
}
