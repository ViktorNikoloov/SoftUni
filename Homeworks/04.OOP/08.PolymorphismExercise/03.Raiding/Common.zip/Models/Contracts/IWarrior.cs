﻿namespace _03.Raiding.Models.Contracts
{
    public interface IWarrior : IHero
    {

    }
}
