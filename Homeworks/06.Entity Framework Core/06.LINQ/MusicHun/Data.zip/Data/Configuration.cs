﻿namespace MusicHub.Data
{
    public static class Configuration
    {
        public static string ConfigurationString = @"Server=.\SQLEXPRESS;Database=MusicHub;Integrated Security=true;";
    }
}
