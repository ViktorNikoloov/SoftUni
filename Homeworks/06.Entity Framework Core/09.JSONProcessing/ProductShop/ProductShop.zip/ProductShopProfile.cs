﻿using AutoMapper;

using ProductShop.Models;
using ProductShop.DataTransferObject.Product;
using ProductShop.DataTransferObject.UsersProducts;
using ProductShop.DataTransferObject.Category;
using System.Linq;
using ProductShop.DataTransferObject.ExportUserAndProducts;

namespace ProductShop
{
    public class ProductShopProfile : Profile
    {
        public ProductShopProfile()
        {
            CreateMap<UserInputModel, User>();

            CreateMap<ProductInputModel, Product>();

            CreateMap<CategoryInputModel, Category>();

            CreateMap<CategoryProductsInput, CategoryProduct>();

            CreateMap<Product, ListProductInRange>()
                .ForMember(x=>x.SellerName, y=>y.MapFrom(x=>x.Seller.FirstName + " " + x.Seller.LastName));

            CreateMap<User, UsersSoldProductsDTO>();

            CreateMap<Category, CategoryByProductCountDTO>()
                .ForMember(cb => cb.Category, c => c.MapFrom(cn => cn.Name))
                .ForMember(cb => cb.ProductsCount, c => c.MapFrom(pc => pc.CategoryProducts.Count))
                .ForMember(cb => cb.AveragePrice, c => c.MapFrom(ap => ap.CategoryProducts.Average(p => p.Product.Price).ToString("F2")))
                .ForMember(cb => cb.TotalRevenue, c => c.MapFrom(tr => tr.CategoryProducts.Sum(tp => tp.Product.Price).ToString("F2")));

            CreateMap<User, UserDTO>()
             .ForMember(x => x.SoldProducts.Count, y => y.MapFrom(x => x.ProductsSold.Where(b => b.BuyerId != null).Count()))
                .ForMember(x => x.SoldProducts.Products, y => y.MapFrom(x => x.ProductsSold.Where(b => b.BuyerId != null)));
            
        }
    }
}
