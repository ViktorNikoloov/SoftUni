﻿namespace ProductShop.DataTransferObject.Product
{
    public class CategoryProductsInput
    {
        public int CategoryId { get; set; }

        public int ProductId { get; set; }
    }
}
